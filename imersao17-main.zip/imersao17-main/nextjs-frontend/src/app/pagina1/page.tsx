import { Button } from "@mui/material";

function Pagina1() {
  return (
    <div>
      <h1>Pagina 1</h1>
      <Button variant="contained" color="primary">aaaaa</Button>
    </div>
  );
}

export default Pagina1;
